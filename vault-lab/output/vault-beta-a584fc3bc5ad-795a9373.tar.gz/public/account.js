import { accessConfiguration } from './access.js';
const $ = selector => document.querySelector(selector);
const phantomButton = $('#account-phantom');
let config, client, verifiedAccount = null, busy = false, inferenceBusy = false, generation = 0, refreshSequence = 0;
const status = message => { $('#account-status').textContent = message; };
const announce = () => document.dispatchEvent(new CustomEvent('vault:account-changed', { detail: verifiedAccount }));

export async function accountHeaders() {
  try { return client ? await client.headers() : {}; }
  catch { throw Object.assign(new Error('Sign in again to verify your account.'), { code:'AUTH_REQUIRED' }); }
}
export const accountState = () => verifiedAccount;
export async function sendTestnetDeposit(prepared) {
  if (!config?.webFundingEnabled || !accountCanPlay()) throw new Error('Testnet funding access is unavailable.');
  return (await ensureClient()).sendTestnetDeposit(prepared);
}
export const accountCanPlay = () => Boolean(verifiedAccount && (config?.closedBeta
  ? verifiedAccount.beta?.admitted === true && verifiedAccount.beta.paused === false
  : !verifiedAccount.beta?.required || (verifiedAccount.beta.admitted && !verifiedAccount.beta.paused)));
export function lockAccount(value) { inferenceBusy = value; render(); }

function render() {
  phantomButton.hidden = !verifiedAccount || !config?.configured;
  phantomButton.disabled = busy || inferenceBusy;
  $('#account-login-form').hidden = Boolean(verifiedAccount) || !config?.configured;
  for (const selector of ['#account-send-code', '#account-login', '#account-wallet', '#account-email', '#account-code']) $(selector).disabled = busy || inferenceBusy;
  $('#account-logout').disabled = busy || inferenceBusy;
  $('#account-logout').hidden = !client;
  $('#account-wallet').hidden = (config?.closedBeta && !config?.webFundingEnabled) || !verifiedAccount || verifiedAccount.wallets.some(w => w.kind === 'embedded');
  if (config?.closedBeta) $('#account-credits').hidden = !config?.webFundingEnabled;
  $('#beta-invite-form').hidden = !config?.closedBeta || !verifiedAccount || verifiedAccount.beta?.admitted;
  $('#beta-invite-code').disabled = $('#beta-redeem').disabled = busy || inferenceBusy;
  $('#account-restore').hidden = !config?.configured || Boolean(verifiedAccount);
  $('#account-restore').disabled = busy || inferenceBusy;
  $('#beta-membership').textContent = !config?.closedBeta ? '' : !verifiedAccount ? 'Closed beta · Sign in, then enter your invitation.'
    : verifiedAccount.beta?.admitted ? (verifiedAccount.beta.paused ? 'Beta paused · Your receipts remain available.' : `Beta access active until ${new Date(verifiedAccount.beta.expiresAt).toLocaleDateString('en-US')}.`)
    : 'An active invitation is required to play.';
  $('#account-summary').textContent = verifiedAccount
    ? `Signed in · ${verifiedAccount.accountId.slice(0, 18)}…${verifiedAccount.wallets.length ? '\n' + verifiedAccount.wallets.map(w => w.address).join('\n') : config?.closedBeta ? '' : '\nNo wallet verified by the server yet.'}`
    : config?.accessMode === 'public-practice' ? 'Sign in to send a practice message.' : 'Not signed in. TEST balances are a separate shared local sandbox.';
}
async function ensureClient() {
  if (!config?.configured) throw new Error('Privy is not configured yet.');
  if (!client) {
    const epoch = generation;
    const module = await import('/vendor/privy.js');
    const created = await module.createPrivyAccount(config);
    if (epoch !== generation) { await created.logout(); throw new Error('Account action cancelled.'); }
    client = created;
  }
  return client;
}
async function refreshIdentity() {
  const headers = await accountHeaders();
  if (!headers.Authorization) return null;
  const response = await fetch('/api/account', { headers, signal: AbortSignal.timeout(12000) });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error?.message || 'Account verification failed.');
  return data;
}
export async function refreshAccountStatus() {
  if (!client || !verifiedAccount || config?.accessMode !== 'public-practice') return;
  const epoch = generation, sequence = ++refreshSequence, owner = verifiedAccount.accountId;
  try {
    const account = await refreshIdentity();
    if (epoch !== generation || sequence !== refreshSequence || owner !== verifiedAccount?.accountId) return;
    verifiedAccount = account; render(); announce();
    if (!accountCanPlay()) { $('#account-usage').textContent = ''; return; }
    const response = await fetch('/api/usage', { headers:await accountHeaders(), signal:AbortSignal.timeout(12000) });
    const usage = await response.json();
    if (epoch !== generation || sequence !== refreshSequence || owner !== verifiedAccount?.accountId) return;
    $('#account-usage').textContent = response.ok
      ? `${Math.max(0, usage.perUserPerDay - usage.requestsToday)} / ${usage.perUserPerDay} attempts left today · resets at 00:00 UTC.${usage.unresolved ? ' Requests paused for cost reconciliation.' : ''}`
      : 'Usage is unavailable. Server limits still apply.';
  } catch {
    if (epoch === generation && sequence === refreshSequence) $('#account-usage').textContent = 'Could not refresh access or usage. Sign in again if your session expired.';
  }
}
$('#account-button').addEventListener('click', () => refreshAccountStatus());
async function action(run, success, verify = true) {
  if (busy || inferenceBusy) return;
  const epoch = generation; busy = true; render();
  try {
    await run();
    const result = verify ? await refreshIdentity() : null;
    if (epoch !== generation) return;
    verifiedAccount = result; announce(); status(success);
    if (result) refreshAccountStatus();
  } catch {
    if (epoch !== generation) return;
    verifiedAccount = null; announce();
    status('Could not complete account verification. Check the code or try again. No payment was made.');
  } finally { if (epoch === generation) { busy = false; render(); } }
}
$('#account-send-code').addEventListener('click', () => {
  if (!$('#account-email').reportValidity()) return;
  action(async () => (await ensureClient()).sendCode($('#account-email').value.trim()), 'Code sent. Enter it below.', false);
});
$('#account-login-form').addEventListener('submit', event => {
  event.preventDefault();
  action(async () => (await ensureClient()).login($('#account-email').value.trim(), $('#account-code').value.trim()), 'Signed in. Your access status is shown below.');
});
$('#account-restore').addEventListener('click', () => action(async () => { await ensureClient(); }, 'Session checked. Sign in with email if no active session was found.'));
$('#beta-invite-form').addEventListener('submit', async event => {
  event.preventDefault();
  if (busy || inferenceBusy || !verifiedAccount) return;
  const epoch = generation; busy = true; render();
  try {
    const response = await fetch('/api/beta/redeem', { method:'POST', headers:{ 'Content-Type':'application/json', ...await accountHeaders() },
      body:JSON.stringify({ code:$('#beta-invite-code').value.trim() }), signal:AbortSignal.timeout(12000) });
    const data = await response.json();
    if (epoch !== generation) return;
    if (!response.ok) { status(data.error?.message || 'Could not redeem your invitation.'); return; }
    verifiedAccount = { ...verifiedAccount, beta:data.beta }; $('#beta-invite-code').value = '';
    announce(); status('Invitation accepted. You can play.'); refreshAccountStatus();
  } catch { if (epoch === generation) status('Could not confirm the invitation. Retry the same code; it can only admit one account.'); }
  finally { if (epoch === generation) { busy = false; render(); } }
});
$('#account-wallet').addEventListener('click', () => action(async () => (await ensureClient()).createWallet(), 'Wallet request completed. Server-verified wallets appear above. Deposits remain disabled.'));
phantomButton.addEventListener('click', async () => {
  if (busy || inferenceBusy || !verifiedAccount) return;
  const epoch = generation; busy = true; render();
  status('In Phantom, select Robinhood Chain Testnet and review the sign-in message. Linking does not transfer tokens.');
  try {
    await (await ensureClient()).connectPhantom();
    const account = await refreshIdentity();
    if (epoch !== generation) return;
    verifiedAccount = account; announce(); status('Wallet linked. The server-verified address is shown above. No tokens were transferred.');
  } catch (error) { if (epoch === generation) status(error.message || 'Wallet linking was not completed.'); }
  finally { if (epoch === generation) { busy = false; render(); } }
});
$('#account-logout').addEventListener('click', async () => {
  if (busy || inferenceBusy) return;
  generation++; busy = false; verifiedAccount = null;
  $('#account-email').value = ''; $('#account-code').value = ''; $('#beta-invite-code').value = ''; $('#account-usage').textContent = '';
  const previous = client; client = null; announce(); render(); status('Signed out locally.');
  try { await previous?.logout(); } catch { status('Signed out locally. Remote session revocation could not be confirmed.'); }
});
async function initialize() {
  try {
    config = await accessConfiguration;
    if (config.accessMode === 'unavailable') throw new Error('Unavailable');
    status(config.configured ? config.webFundingEnabled ? 'Sign in to test wallet funding.' : 'Email sign-in is available. Deposits are disabled.' : 'Privy integration prepared. App configuration is still required.');
  } catch { status('Account configuration is unavailable. Reload to retry.'); }
  render();
}
initialize();
