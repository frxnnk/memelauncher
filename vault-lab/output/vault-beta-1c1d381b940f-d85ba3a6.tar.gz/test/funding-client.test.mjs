import test from 'node:test';
import assert from 'node:assert/strict';
import { createTopupController, tokenAmount, displayTokens } from '../public/funding-client.js';

function fixture() {
  const records = new Map(), requests = [], controls = {}; let sends = 0;
  const storage = { getItem: key => records.get(key), setItem: (key, value) => records.set(key, value) };
  const api = async (path, body) => {
    requests.push({ path, body }); if (controls.fail) throw new Error('Connection lost');
    return { order: { id: 'order1', credited: Boolean(controls.credited) }, transfer: { signingEnabled: true } };
  };
  const make = () => createTopupController({ api, storage, storageKey: 'alice', uuid: () => 'stable-key',
    send: async () => { sends++; if (controls.sendError) throw controls.sendError; return '0x' + 'a'.repeat(64); } });
  return { make, controls, requests, get sends() { return sends; } };
}
test('token amounts use exact base units and reject exponent notation, negative, precision and overflow', () => {
  assert.equal(tokenAmount('1.000001', 6), '1000001'); assert.equal(displayTokens('1000001', 6), '1.000001');
  for (const value of ['1e6', '-1', '0', 'NaN', '0.0000001', '9'.repeat(80)]) assert.throws(() => tokenAmount(value, 6));
});
test('lost prepare response retains the same key, and cannot silently change the amount', async () => {
  const f = fixture(), c = f.make(), input = { wallet: 'alice', amountBaseUnits: '100' };
  f.controls.fail = true; await assert.rejects(c.prepare(input));
  f.controls.fail = false; await c.prepare(input);
  assert.equal(f.requests[0].body.key, f.requests[1].body.key);
  await assert.rejects(c.prepare({ ...input, amountBaseUnits: '200' })); assert.equal(f.sends, 0);
});
test('uncertain wallet send survives reload and blocks a second signature; known hash recovers without resending', async () => {
  const f = fixture(), c = f.make(); await c.prepare({ amountBaseUnits: '100' });
  f.controls.sendError = new Error('Lost wallet response'); await assert.rejects(c.confirm());
  const restored = f.make(); await assert.rejects(restored.confirm()); assert.equal(f.sends, 1);
  f.controls.credited = true; await restored.recover('0x' + 'b'.repeat(64));
  assert.equal(restored.read().state, 'complete'); assert.equal(f.sends, 1);
});
test('an explicit user rejection may be reviewed again; concurrent confirms only send once', async () => {
  const f = fixture(), c = f.make(); await c.prepare({ amountBaseUnits: '100' });
  f.controls.sendError = Object.assign(new Error('Rejected'), { code: 4001 }); await assert.rejects(c.confirm());
  assert.equal(c.read().state, 'prepared'); delete f.controls.sendError;
  const results = await Promise.allSettled([c.confirm(), c.confirm()]);
  assert.equal(results.filter(x => x.status === 'fulfilled').length, 1); assert.equal(f.sends, 2);
});
