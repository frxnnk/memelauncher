import { FUNDING_NETWORK, checkedDepositTransaction } from '../public/funding-network.js';
import { getAddress } from 'viem';

export function phantomProvider() {
  const provider = window.phantom?.ethereum;
  if (!provider?.request) throw new Error('Open this site in the Phantom mobile browser, or install the Phantom extension. Enable Robinhood Chain Testnet in Phantom settings.');
  return provider;
}
export async function selectFundingNetwork(provider) {
  await provider.request({ method: 'wallet_switchEthereumChain', params: [{ chainId: FUNDING_NETWORK.hexId }] });
  const chainId = await provider.request({ method: 'eth_chainId' });
  if (BigInt(chainId) !== BigInt(FUNDING_NETWORK.chainId)) throw new Error('Select Robinhood Chain Testnet in your wallet.');
}
export async function linkPhantom(privy, provider = phantomProvider(), onProgress = () => {}) {
  const { user } = await privy.user.get();
  if (!user) throw new Error('Sign in before linking Phantom.');
  const addresses = await provider.request({ method: 'eth_requestAccounts' });
  const rawAddress = addresses?.[0];
  if (typeof rawAddress !== 'string' || !/^0x[0-9a-f]{40}$/i.test(rawAddress)) throw new Error('Phantom did not return an Ethereum address.');
  // Privy core embeds the address verbatim. EIP-4361 requires the EIP-55
  // checksum, even when eth_requestAccounts returns all lowercase.
  const address = getAddress(rawAddress);
  // SIWE identifies this EVM address; it does not authorize a deposit. Use the
  // wallet's current chain so linking never requires enabling testnet mode.
  const currentChain = await provider.request({ method: 'eth_chainId' });
  if (typeof currentChain !== 'string' || !/^0x[0-9a-f]{1,16}$/i.test(currentChain) || BigInt(currentChain) <= 0n) throw new Error('Phantom did not return a valid EVM network.');
  const wallet = { address, chainId: 'eip155:' + BigInt(currentChain).toString(), walletClientType: 'phantom', connectorType: 'injected' };
  const { message } = await privy.auth.siwe.init(wallet, window.location.host, window.location.origin);
  const beforeSign = await provider.request({ method: 'eth_accounts' });
  const chainBeforeSign = await provider.request({ method: 'eth_chainId' });
  if (beforeSign?.[0]?.toLowerCase() !== address.toLowerCase() || BigInt(chainBeforeSign) !== BigInt(currentChain)) throw new Error('Your Phantom account or network changed. Connect again with the same account selected.');
  onProgress({ address, chainId: BigInt(currentChain).toString() });
  const encoded = '0x' + Array.from(new TextEncoder().encode(message), byte => byte.toString(16).padStart(2, '0')).join('');
  let signature;
  try { signature = await provider.request({ method: 'personal_sign', params: [encoded, address] }); }
  catch (error) {
    if (/address.*(not match|mismatch)/i.test(error.message || '')) throw new Error(`Phantom could not match ${address} to the selected account (chain ${BigInt(currentChain)}). Select that same EVM account in Phantom, then reconnect. No wallet was linked.`);
    throw error;
  }
  const accounts = await provider.request({ method: 'eth_accounts' });
  const latest = await privy.user.get();
  if (latest.user?.id !== user.id || accounts?.[0]?.toLowerCase() !== address.toLowerCase()) throw new Error('Your account or wallet changed during linking. Start again.');
  return privy.auth.siwe.linkWithSiwe(signature, wallet, message);
}
export async function sendPhantomDeposit(prepared, provider = phantomProvider()) {
  const tx = checkedDepositTransaction(prepared);
  const accounts = await provider.request({ method: 'eth_accounts' });
  if (accounts?.[0]?.toLowerCase() !== tx.from.toLowerCase()) throw new Error('Select the Phantom account shown in your top-up order.');
  await selectFundingNetwork(provider);
  const current = await provider.request({ method: 'eth_accounts' });
  if (current?.[0]?.toLowerCase() !== tx.from.toLowerCase()) throw new Error('Your Phantom account changed. Review the top-up again.');
  return provider.request({ method: 'eth_sendTransaction', params: [checkedDepositTransaction(prepared)] });
}
