// One configuration request shared by account, chat and accounting controls.
export const accessConfiguration = fetch('/api/auth/config', { signal: AbortSignal.timeout(10000) })
  .then(async response => {
    if (!response.ok) throw new Error('Account configuration unavailable.');
    const config = await response.json();
    document.documentElement.dataset.access = config.accessMode;
    if (config.accessMode === 'public-practice') {
      document.querySelector('#treasury-title').textContent = 'Your account.';
      document.querySelector('.treasury-label').textContent = 'Practice / no real prize';
      document.querySelector('.treasury-intro').textContent = 'Sign in to challenge the guardians. Each reply has a receipt. Deposits and payouts are disabled.';
      document.querySelector('#use-test-credits').checked = false;
      document.querySelector('#practice-footer').textContent = 'Practice / No real prize';
      if (config.closedBeta) {
        document.querySelector('#practice-footer').textContent = 'Closed beta / No cash prize';
        document.querySelector('.treasury-intro').textContent = 'Sign in and enter your invitation to challenge the AI guardians. Your account shows your access and daily allowance.';
        document.querySelector('.treasury-section:has(#account-status) > h3').textContent = 'Your beta access';
        document.querySelector('#account-mode-note').textContent = 'Practice beta. No wallet, deposit or cash prize. Your invitation grants access to the game.';
      }
    }
    return config;
  }).catch(() => ({ configured: false, accessMode: 'unavailable', sandboxEnabled: false }));
