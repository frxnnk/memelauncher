import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createVaultService } from './server/service.mjs';
import { createHttpServer } from './server/http.mjs';
import { mkdirSync } from 'node:fs';
import { createEconomyService } from './server/economy/service.mjs';
import { createCreditGame } from './server/economy/model-game.mjs';
import { createAuthentication } from './server/auth.mjs';
import { runtimeConfiguration } from './server/runtime.mjs';
import { createInferenceLimits } from './server/limits.mjs';
import { validateKeyBudget } from './server/key-budget.mjs';
import { fetchJson } from './server/errors.mjs';
import { createTelegramApi, startTelegram } from './server/telegram.mjs';
import { createTelegramStore } from './server/telegram-store.mjs';
import { createBetaAccess } from './server/beta-access.mjs';

const root = dirname(fileURLToPath(import.meta.url));
const runtime = runtimeConfiguration(process.env);
const telegramEnabled = process.env.VAULT_TELEGRAM_ENABLED === 'true';
if (telegramEnabled && runtime.mode !== 'public-practice') throw new Error('Telegram requires public-practice mode so web and bot share persistent usage limits.');
if (telegramEnabled && runtime.closedBeta) throw new Error('Telegram is disabled for the web closed beta until bot admission is implemented.');
const port = Number(process.env.PORT || 4319);
if (!Number.isInteger(port) || port < 1 || port > 65535) {
  console.error('PORT must be an integer between 1 and 65535.');
  process.exit(1);
}
mkdirSync(join(root, '.local'), { recursive: true });
const service = createVaultService({
  apiKey: process.env.OPENROUTER_API_KEY || '', logDir: join(root, '.local'), sessionsPath: join(root, '.local', 'sessions.sqlite')
});
const economy = createEconomyService({ path: join(root, '.local', 'economy-sandbox.sqlite') });
const creditGame = createCreditGame({ path: join(root, '.local', 'model-jobs.sqlite'), economy, vault: service });
const authentication = createAuthentication({ appId: process.env.PRIVY_APP_ID, clientId: process.env.PRIVY_CLIENT_ID,
  verificationKey: process.env.PRIVY_VERIFICATION_KEY?.replaceAll('\\n', '\n') });
let limits;
if (runtime.mode === 'public-practice') {
  if (!authentication.configured || !process.env.OPENROUTER_API_KEY) throw new Error('Public practice requires Privy configuration and a dedicated limited API key.');
  try {
    const keyInfo = await fetchJson(fetch, 'https://openrouter.ai/api/v1/key', {
      headers: { Authorization: `Bearer ${process.env.OPENROUTER_API_KEY}` }
    }, 15000);
    validateKeyBudget(keyInfo.data, runtime.budgetUsd);
  } catch { throw new Error('Public practice cannot start: the provider key budget could not be verified. No inference was requested.'); }
  limits = createInferenceLimits({ path: join(root, '.local', 'usage.sqlite'), ...runtime });
}
const beta = runtime.closedBeta ? createBetaAccess({ path:join(root, '.local', 'beta.sqlite') }) : undefined;
let telegram, telegramStore;
if (telegramEnabled) {
  telegramStore = createTelegramStore(join(root, '.local', 'telegram.sqlite'));
  telegram = await startTelegram({ api: createTelegramApi({ token: process.env.TELEGRAM_BOT_TOKEN }),
    vault: service, limits, store: telegramStore, defaultModel: process.env.TELEGRAM_MODEL_ID || 'google/gemini-2.5-flash', onWarning: console.warn });
}
const server = createHttpServer({ service, economy, creditGame, authentication, limits, beta, runtime,
  channels: () => ({ telegram: telegram?.state ?? { enabled: false } }), publicDir: join(root, 'public') });
server.on('error', error => {
  console.error(error.code === 'EADDRINUSE'
    ? `Port ${port} is in use. Choose a different PORT.`
    : 'Could not start the local server.');
  shutdown(1);
});
const bindAddress = runtime.mode === 'public-practice' ? (process.env.VAULT_BIND_ADDRESS || '127.0.0.1') : '127.0.0.1';
server.listen(port, bindAddress, () => {
  console.log(`Dear Vault practice: http://127.0.0.1:${port}`);
  console.log(runtime.mode === 'public-practice' ? 'Authenticated practice only. No deposits or funded bounty. Serve behind the configured HTTPS origin.' : 'Local only. No real funds or prize.');
  console.log(service.status().configured ? 'API configured: live attempts may incur charges.' : 'API not configured: add OPENROUTER_API_KEY to .env to enable inference.');
});
let stopping = false;
function shutdown(exitCode = 0) {
  if (stopping) return;
  stopping = true;
  const botStopped = telegram?.stop();
  server.close(async () => {
    await botStopped; telegramStore?.close();
    beta?.close(); limits?.close(); service.close(); creditGame.close(); economy.close(); process.exit(exitCode);
  });
}
for (const signal of ['SIGINT', 'SIGTERM']) process.on(signal, () => shutdown());
