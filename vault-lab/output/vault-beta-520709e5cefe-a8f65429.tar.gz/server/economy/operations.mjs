import { id, units, playerAccount, roundAccount, PENDING, roundTerms } from './schema.mjs';

export function applyOperation(db, balances, request) {
  const { get, add, move } = balances;
  const positive = value => { const n = units(value); if (!n) throw new Error('Amount must be positive.'); return n; };
  const round = value => {
    const row = db.prepare('SELECT * FROM rounds WHERE id = ?').get(id(value));
    if (!row) throw new Error('Round not found.');
    return row;
  };
  const attempt = value => {
    const row = db.prepare('SELECT * FROM attempts WHERE id = ?').get(id(value));
    if (!row) throw new Error('Attempt not found.');
    return row;
  };
  const changeAttempt = (a, state, reference = null) => db.prepare('UPDATE attempts SET state = ?, receipt_ref = ? WHERE id = ?').run(state, reference, a.id);
  const firstPending = roundId => db.prepare("SELECT * FROM attempts WHERE round_id = ? AND state IN ('reserved','processing','unknown') ORDER BY position LIMIT 1").get(roundId);
  const refund = a => {
    move(playerAccount(a.player, 'reserved'), playerAccount(a.player, 'available'), units(a.price));
    changeAttempt(a, 'cancelled');
  };

  if (request.type === 'open-round') {
    id(request.roundId);
    const { price, prizeBps, operationsBps } = roundTerms(request);
    if (typeof request.configuration !== 'string' || !request.configuration.trim() || request.configuration.length > 200) throw new Error('A public configuration reference is required.');
    db.prepare('INSERT INTO rounds(id,state,price,prize_bps,operations_bps,configuration) VALUES (?, ?, ?, ?, ?, ?)')
      .run(request.roundId, 'open', String(price), prizeBps, operationsBps, request.configuration);
    return { roundId: request.roundId, state: 'open' };
  }
  if (request.type === 'topup') {
    const amount = positive(request.amount);
    add('custody', amount); add(playerAccount(request.player, 'available'), amount);
    return { player: request.player, received: String(amount), source: 'simulated-topup' };
  }
  if (request.type === 'refund-credits') {
    const amount = positive(request.amount);
    add(playerAccount(request.player, 'available'), -amount); add('custody', -amount);
    return { player: request.player, refunded: String(amount), source: 'simulated-refund' };
  }
  if (request.type === 'contribution') {
    const r = round(request.roundId);
    if (r.state !== 'open') throw new Error('Contributions require an open round.');
    if (!['seed', 'sponsor', 'creator-fees'].includes(request.source)) throw new Error('Unknown contribution source.');
    if (request.received !== true) throw new Error('An estimate or promised contribution is not received funds.');
    const amount = positive(request.amount);
    add('custody', amount); add(roundAccount(r.id, 'prize'), amount);
    return { roundId: r.id, received: String(amount), source: request.source };
  }
  if (request.type === 'seed-next-round') {
    const r = round(request.roundId);
    if (r.state !== 'open') throw new Error('Seed requires an open round.');
    const amount = positive(request.amount);
    move('treasury:next', roundAccount(r.id, 'prize'), amount);
    return { roundId: r.id, assigned: String(amount), source: 'next-round-reserve' };
  }
  if (request.type === 'reserve') {
    const r = round(request.roundId);
    if (r.state !== 'open') throw new Error('This round no longer accepts attempts.');
    id(request.attemptId); id(request.player);
    move(playerAccount(request.player, 'available'), playerAccount(request.player, 'reserved'), units(r.price));
    db.prepare('INSERT INTO attempts(id,round_id,player,state,price) VALUES (?, ?, ?, ?, ?)').run(request.attemptId, r.id, request.player, 'reserved', r.price);
    return { attemptId: request.attemptId, state: 'reserved', price: r.price };
  }
  if (request.type === 'start') {
    const a = attempt(request.attemptId);
    if (a.state !== 'reserved' || firstPending(a.round_id)?.id !== a.id || round(a.round_id).state !== 'open') throw new Error('Only the first reserved attempt can start.');
    changeAttempt(a, 'processing');
    return { attemptId: a.id, state: 'processing' };
  }
  if (request.type === 'unknown') {
    const a = attempt(request.attemptId);
    if (a.state !== 'processing') throw new Error('Only a processing attempt can become uncertain.');
    changeAttempt(a, 'unknown');
    return { attemptId: a.id, state: 'unknown', creditsReserved: a.price };
  }
  if (request.type === 'cancel-reservation') {
    const a = attempt(request.attemptId);
    if (a.state !== 'reserved') throw new Error('A started or uncertain attempt must be reconciled, not cancelled.');
    refund(a);
    return { attemptId: a.id, state: 'cancelled', creditsReturned: a.price };
  }
  if (request.type === 'settle') {
    const a = attempt(request.attemptId);
    const r = round(a.round_id);
    if (!['processing', 'unknown'].includes(a.state) || firstPending(a.round_id)?.id !== a.id || r.state !== 'open') throw new Error('Attempt cannot be settled in this state or order.');
    if (a.state === 'unknown' && request.reconciled !== true) throw new Error('An uncertain outcome requires explicit reconciliation.');
    if (!['locked', 'released', 'error'].includes(request.outcome)) throw new Error('Invalid settlement outcome.');
    const reference = id(request.receiptRef);
    const price = units(a.price);
    const reserved = playerAccount(a.player, 'reserved');
    if (request.outcome === 'error') {
      move(reserved, playerAccount(a.player, 'available'), price);
      changeAttempt(a, 'error', reference);
      return { attemptId: a.id, state: 'error', creditsReturned: a.price, prizeContribution: '0' };
    }
    const prize = price * BigInt(r.prize_bps) / 10000n;
    const operations = price * BigInt(r.operations_bps) / 10000n;
    const next = price - prize - operations;
    move(reserved, roundAccount(r.id, 'prize'), prize);
    move(reserved, 'treasury:operations', operations);
    move(reserved, 'treasury:next', next);
    changeAttempt(a, request.outcome, reference);
    let winnerPayable = 0n;
    if (request.outcome === 'released') {
      winnerPayable = get(roundAccount(r.id, 'prize'));
      move(roundAccount(r.id, 'prize'), roundAccount(r.id, 'payable'), winnerPayable);
      db.prepare("UPDATE rounds SET state = 'won', winner = ? WHERE id = ?").run(a.player, r.id);
      for (const pending of db.prepare("SELECT * FROM attempts WHERE round_id = ? AND state = 'reserved'").all(r.id)) refund(pending);
    }
    return { attemptId: a.id, state: request.outcome, prizeContribution: String(prize), operations: String(operations),
      nextRound: String(next), winnerPayable: String(winnerPayable) };
  }
  if (request.type === 'payout') {
    const r = round(request.roundId);
    if (r.state !== 'won' || !r.winner) throw new Error('Only an unpaid winning round can be paid.');
    const amount = get(roundAccount(r.id, 'payable'));
    add(roundAccount(r.id, 'payable'), -amount); add('custody', -amount);
    db.prepare("UPDATE rounds SET state = 'paid' WHERE id = ?").run(r.id);
    return { roundId: r.id, player: r.winner, paid: String(amount), source: 'simulated-payout' };
  }
  throw new Error('Unknown accounting operation.');
}

export function auditLedger(db, get) {
  const rows = db.prepare('SELECT account, amount FROM balances').all();
  const held = get('custody');
  const obligations = rows.filter(row => row.account !== 'custody').reduce((sum, row) => sum + units(row.amount), 0n);
  if (held !== obligations) throw new Error('Ledger conservation failed.');
  const reserved = new Map();
  for (const a of db.prepare('SELECT * FROM attempts').all()) if (PENDING.includes(a.state)) {
    const account = playerAccount(a.player, 'reserved');
    reserved.set(account, (reserved.get(account) ?? 0n) + units(a.price));
  }
  for (const row of rows.filter(row => row.account.endsWith(':reserved'))) if (units(row.amount) !== (reserved.get(row.account) ?? 0n)) throw new Error('Reserved credit reconciliation failed.');
  for (const [account, amount] of reserved) if (get(account) !== amount) throw new Error('Missing reserved credits.');
  return { balanced: true, custody: String(held), liabilitiesAndAllocations: String(obligations) };
}
