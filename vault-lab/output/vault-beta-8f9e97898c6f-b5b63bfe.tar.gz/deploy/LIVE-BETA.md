# Live Vault closed beta

Verified 2026-09-15 UTC. Public landing: https://vault-closed-beta.vercel.app; game: https://vault-closed-beta.vercel.app/play. Authentication plus an active invitation is required for inference. The URL alone grants no model access. This is practice with no deposits, token or cash prize.

## Deployment inventory

| Component | Actual destination |
|---|---|
| Static web | Vercel project `vault-closed-beta`, team `frxn` |
| Web deployment | `dpl_8DZWp69fg5E8fedLQwWAoH8Z8yiW` |
| Node API | Existing `ferced-vps`, service `vault-beta`, Node 24.18.0 |
| Backend release | `C:\vault-beta\releases\e6a7e1e9ae99` |
| Service identity | `NT SERVICE\vault-beta` |
| Private configuration | `C:\vault-beta\shared\.env` |
| Persistent data | `C:\vault-beta\shared\data` (release `.local` junction) |
| Process logs | `C:\vault-beta\shared\logs`, rotated at 1 MB |
| Internal listener | `127.0.0.1:4319` |
| API proxy | `https://vault-beta-api.173.212.246.68.sslip.io/api/*` |

Vercel rewrites `/api/*` to Caddy on the existing VPS. Caddy forwards the canonical Host; the API checks the exact browser Origin. Only API paths are exposed by this hostname. The `sslip.io` hostname is temporary and depends on that external DNS service. Existing Caddy sites were preserved. No Docker or new hosting purchase was needed. Only the static frontend runs on Vercel; SQLite remains on persistent VPS disk.

The public production alias has no `-frxn` suffix. Preview/team aliases may require Vercel sign-in. Keep that preview protection. Both Privy app and client allow the canonical HTTPS origin; the development Privy app's user cap is sufficient for this five-tester beta.

The backend source archive is identified in `output/beta-deployed-backend-package.json`. Later local packaging adds deployment/build documentation; it is not a second live backend release. The frontend and backend have separate deployment identifiers. Git remains local without a commit or remote; Vercel was deployed by CLI.

## Admission and operating limits

Gemini 2.5 Flash and Claude Haiku 4.5 are enabled. Qwen is kept in the local lab after two provider 429s. The active public prompt remains `vault-practice-v2-en-2026-09-14`; the experimental defense prompt is not active.

- 25 requests per account/day, 250 globally/day; UTC reset.
- One active inference globally; simultaneous requests can receive a busy response. Appropriate for the initial five testers, not a load-tested public launch.
- Dedicated OpenRouter key: cumulative USD 5, no reset, BYOK included. Prior evaluations consume the same cap. No automatic replenishment.
- Owner invitation redeemed; five tester codes issued, not sent. Private local copy: `.local/beta-testers.json`. Each admits one account and expires seven days after issuance, on September 22 UTC (September 21 evening in Argentina).
- Feedback and removal requests go to the person who sends the invitation. Server records contain prompts/replies and remain during the beta; automatic deletion is not implemented. The public data notice discloses this.
- Telegram cannot start with closed-beta mode until it supports invitation admission. No bot is live.

Run these on the VPS from the deployed release. Always specify the actual shared database when using a custom invitation output path; the `.local` junction is not normalized by the CLI's containment check.

```powershell
$vaultRelease='C:\vault-beta\releases\e6a7e1e9ae99'
$vaultDb='C:\vault-beta\shared\data\beta.sqlite'
Set-Location $vaultRelease
node scripts/beta.mjs list --db $vaultDb
node scripts/beta.mjs pause --db $vaultDb
node scripts/beta.mjs resume --db $vaultDb
node scripts/beta.mjs revoke --db $vaultDb --id INVITATION_ID
node scripts/beta.mjs issue --db $vaultDb --label 'Tester 6' --days 7
```

The last command writes a new private JSON; it never sends a message. Do not put invitation codes in URLs, public documentation, Vercel output or Git. Do not recreate or reenable the temporary OpenRouter management key; activation completed and that key was disabled.

## Verified recovery and rollback

`output/beta-live-web-verification.json` records three real browser requests, one admitted owner, two saved conversations and five SQLite integrity checks. A stopped-writer backup was hashed and checked; the service restarted with identical session and receipt hashes. Backup: `C:\vault-beta\shared\backups\data-live-20260915044810`. It contains private data and invitation codes. It is not a public artifact.

After a page reload, choose **Sign in → Restore existing session**, then **Receipts** to retrieve saved results without another inference. The active conversation is not rebuilt on the page; the footer count describes receipts loaded in the current tab. This is a known beta UX limitation, not data loss.

For subsequent backups: pause admission writes, inspect `/api/health` for zero pending/busy calls, stop `vault-beta`, copy the entire shared data directory to a new private backup, check hashes and every SQLite `PRAGMA integrity_check`, restart, verify saved state, then resume. A paused backup restores paused. Never overwrite running databases or replace a pending/unknown inference with a fresh request.

For rollback of code, pause and retain current data, stop only `vault-beta`, point NSSM `AppDirectory` and `AppParameters` at a previously verified release with its junction to the same shared data, then restart and check health before resuming. Do not roll the usage database backwards to recover budget. Initial deployment has no earlier beta binary to roll back to: stop the beta service and remove only its Caddy route if withdrawal is needed. Keep the pre-beta Caddy backups for comparison; never overwrite changes made later to other sites.

Vercel frontend rollback can promote a known working deployment independently. Do not promote the earlier deployment whose root served the game instead of the landing. For changes to runtime code, create a fresh verified backend archive; the initial installer refuses to overwrite an existing service.

## Release evidence

- `output/beta-deployment-http.json`: HTTPS and unauthenticated/origin denials.
- `output/beta-browser-verification.json`: actual Privy login, redemption, replies, receipt recovery and responsive checks.
- `output/beta-live-web-verification.json`: receipt IDs, provider costs and restart/backup evidence.
- `output/beta-evaluation.json`: compatibility controls and static adversarial results, including the failed Qwen run.
- `output/beta-provider-budget.json`: latest provider-reported spend and remaining key limit.

These are operator records. They do not independently attest provider execution, promise jailbreak resistance or establish a funded payout mechanism.
