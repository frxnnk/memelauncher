import test from 'node:test';
import assert from 'node:assert/strict';
import { createTopupController, tokenAmount, displayTokens } from '../public/funding-client.js';

function fixture() {
  const records = new Map(), requests = [], controls = {}; let sends = 0;
  const storage = { getItem: key => records.get(key), setItem: (key, value) => records.set(key, value) };
  const api = async (path, body) => {
    requests.push({ path, body }); if (controls.fail) throw new Error('Connection lost');
    return { order: { id: 'order1', credited: Boolean(controls.credited), expiresAt: Date.now() + 60000,
      submittedTransactionHash: controls.submittedHash }, transfer: { signingEnabled: true } };
  };
  const make = () => createTopupController({ api, storage, storageKey: 'alice', uuid: () => 'stable-key',
    send: async () => { sends++; if (controls.sendError) throw controls.sendError; return '0x' + 'a'.repeat(64); } });
  return { make, controls, requests, get sends() { return sends; } };
}
test('wallet progress precedes signing and a confirmed deposit is not sent twice after reload', async () => {
  const data = new Map(), progress = [];
  let sends = 0;
  const storage = { getItem: key => data.get(key), setItem: (key, value) => data.set(key, value) };
  const api = async () => ({ order: { id: 'id', credited: sends > 0, expiresAt: Date.now() + 60000 }, transfer: { signingEnabled: true } });
  const make = () => createTopupController({ api, storage, storageKey: 'x', uuid: () => 'key', onProgress: stage => progress.push(stage),
    send: async () => { assert.equal(progress.at(-1), 'wallet'); sends++; return '0x' + 'a'.repeat(64); } });
  await make().prepare({ amountBaseUnits: '100' });
  await make().confirm();
  assert.deepEqual(progress, ['review', 'wallet', 'confirmations']);
  await assert.rejects(make().confirm());
  await make().recover();
  assert.equal(sends, 1);
});

test('token amounts use exact base units and reject exponent notation, negative, precision and overflow', () => {
  assert.equal(tokenAmount('1.000001', 6), '1000001'); assert.equal(displayTokens('1000001', 6), '1.000001');
  for (const value of ['1e6', '-1', '0', 'NaN', '0.0000001', '9'.repeat(80)]) assert.throws(() => tokenAmount(value, 6));
});
test('lost prepare response retains the same key, and cannot silently change the amount', async () => {
  const f = fixture(), c = f.make(), input = { wallet: 'alice', amountBaseUnits: '100' };
  f.controls.fail = true; await assert.rejects(c.prepare(input));
  f.controls.fail = false; await c.prepare(input);
  assert.equal(f.requests[0].body.key, f.requests[1].body.key);
  await assert.rejects(c.prepare({ ...input, amountBaseUnits: '200' })); assert.equal(f.sends, 0);
});
test('uncertain wallet send survives reload and blocks a second signature; known hash recovers without resending', async () => {
  const f = fixture(), c = f.make(); await c.prepare({ amountBaseUnits: '100' });
  f.controls.sendError = new Error('Lost wallet response'); await assert.rejects(c.confirm());
  const restored = f.make(); await assert.rejects(restored.confirm()); assert.equal(f.sends, 1);
  f.controls.credited = true; await restored.recover('0x' + 'b'.repeat(64));
  assert.equal(restored.read().state, 'complete'); assert.equal(f.sends, 1);
});
test('an explicit user rejection may be reviewed again; concurrent confirms only send once', async () => {
  const f = fixture(), c = f.make(); await c.prepare({ amountBaseUnits: '100' });
  f.controls.sendError = Object.assign(new Error('Rejected'), { code: 4001 }); await assert.rejects(c.confirm());
  assert.equal(c.read().state, 'prepared'); delete f.controls.sendError;
  const results = await Promise.allSettled([c.confirm(), c.confirm()]);
  assert.equal(results.filter(x => x.status === 'fulfilled').length, 1); assert.equal(f.sends, 2);
});

test('local wallet preflight errors allow review without treating an uncalled send as uncertain', async () => {
  const f = fixture(), c = f.make(); await c.prepare({ amountBaseUnits: '100' });
  f.controls.sendError = Object.assign(new Error('Wrong account'), { code: 'VAULT_WALLET_NOT_SENT' });
  await assert.rejects(c.confirm()); assert.equal(c.read().state, 'prepared');
  f.controls.sendError = new Error('Disconnected after send');
  await assert.rejects(c.confirm()); assert.equal(c.read().state, 'signing-unknown');
});

test('legacy unknown state needs explicit no-signature acknowledgement and rejects a recorded hash', async () => {
  const f = fixture(), c = f.make(); await c.prepare({ amountBaseUnits: '100' });
  f.controls.sendError = new Error('Old wallet preflight failure'); await assert.rejects(c.confirm());
  await assert.rejects(c.acknowledgeNotSigned());
  f.controls.submittedHash = '0x' + 'a'.repeat(64);
  await assert.rejects(c.acknowledgeNotSigned({ confirmedNoSignature: true }), /already recorded/);
  delete f.controls.submittedHash;
  await c.acknowledgeNotSigned({ confirmedNoSignature: true });
  assert.equal(c.read().state, 'prepared'); assert.equal(c.read().userConfirmedNotSigned, true);
  assert.equal(f.sends, 1);
});
