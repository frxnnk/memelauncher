import { accountState, accountCanPlay, sendTestnetDeposit, lockAccount } from './account.js';
import { accessConfiguration } from './access.js';
import { showInfo } from './details.js';
import { createTopupController, displayTokens, tokenAmount } from './funding-client.js';
import { fundingRequest, refreshWebFunding, selectWebCredits, usesWebCredits, recoverWebAttempt, pendingWebAttempt, fundingWallet, chooseFundingWallet } from './web-credits.js';

const node = (tag, text) => { const element = document.createElement(tag); element.textContent = text ?? ''; return element; };
const button = (root, label, action) => {
  const element = node('button', label); element.type = 'button'; element.className = 'treasury-action';
  element.addEventListener('click', action); root.append(element); return element;
};
let generation = 0, busy = false, activeOwner = null;
async function openFunding() {
  const epoch = ++generation, owner = accountState()?.accountId;
  activeOwner = owner;
  const host = showInfo('Top up & bounty', 'TESTNET REHEARSAL');
  const root = node('section'); root.className = 'funding-panel'; host.append(root);
  const current = () => generation === epoch && accountState()?.accountId === owner && root.isConnected;
  root.append(node('p', 'Loading…'));
  try {
    const config = await refreshWebFunding();
    if (!current()) return;
    root.replaceChildren();
    if (!config.enabled || !accountCanPlay()) { root.append(node('p', 'Sign in with an active beta invitation first.')); return; }
    const amount = value => displayTokens(value, config.asset.decimals);
    root.append(node('p', 'Test tokens only. No monetary value or cash payout.'));
    const disclosure = node('details'); disclosure.append(node('summary', 'Network, rules & custody'));
    const details = node('p', `Chain ${config.asset.chainId}\nToken ${config.asset.tokenAddress}\nRecipient ${config.asset.destination}`);
    details.style.whiteSpace = 'pre-line'; disclosure.append(details);
    const account = await fundingRequest('/api/funding/account'); if (!current()) return;
    const balances = node('p', `${amount(account.available)} available`); balances.className = 'funding-balance'; root.append(balances);
    root.append(node('p', `${amount(account.reserved)} reserved · Test tokens`));
    for (const round of config.rounds) {
      const model = round.manifest.manifest.configuration.guardians.map(g => g.modelId).join(', ');
      root.append(node('p', `${model.split('/').at(-1)} · Bounty ${amount(round.bounty)}`));
      disclosure.append(node('p', `${model} · ${round.state}\nPayable ${amount(round.prizePayable)}\n${amount(round.price)} per completed attempt · ${round.prizeBps / 100}% bounty / ${round.operationsBps / 100}% operations / ${round.nextRoundBps / 100}% next round.`));
    }
    disclosure.append(node('p', 'Your top-up stays in your credit balance until used. Confirmed errors return the reserved credit. Uncertain replies stay reserved for recovery. The operator controls custody and records model results.'));
    const status = node('p'); status.setAttribute('role', 'status');
    const controls = node('div'); controls.className = 'treasury-buttons'; root.append(controls, status);
    async function run(work) {
      if (busy || !current()) return;
      busy = true; lockAccount(true);
      for (const control of root.querySelectorAll('button,input,select')) control.disabled = true;
      try { const message = await work(); if (current()) status.textContent = message; }
      catch (error) {
        if (current()) status.textContent = error.message + (error.code === 'VAULT_WALLET_NOT_SENT'
          ? ' No transfer was requested.' : error.code === 4001 ? ' The wallet request was cancelled.'
            : ' If a transfer may have been sent, recover it below. Do not send it again.');
      }
      finally {
        busy = false; lockAccount(false);
        if (current()) for (const control of root.querySelectorAll('button,input,select')) control.disabled = false;
      }
    }
    button(controls, usesWebCredits() ? 'Use free practice' : 'Use testnet credits in chat', () => {
      if (document.querySelector('#chat-thread').children.length) { status.textContent = 'Start a new conversation before changing between practice and credit play. Your existing receipts stay available.'; return; }
      selectWebCredits(!usesWebCredits()); document.querySelector('#info-dialog').close(); document.querySelector('#treasury-dialog').close();
      document.querySelector('#practice-footer').textContent = usesWebCredits() ? 'Testnet credits · no monetary value' : 'Practice / No cash prize';
    });
    if (pendingWebAttempt()) button(controls, 'Recover pending reply', () => run(async () => {
      const result = await recoverWebAttempt();
      if (result?.receipt) document.dispatchEvent(new CustomEvent('vault:recovered-receipt', { detail: result.receipt }));
      return 'Reply recovered. No new model request was sent.';
    }));
    let wallet = fundingWallet();
    if (!wallet) { root.append(node('p', 'Connect Phantom in Account, then return here.')); root.append(disclosure); return; }
    const guide = node('details'); guide.className = 'funding-wallet-guide';
    guide.append(node('summary', 'Before you top up with Phantom'));
    guide.append(node('p', 'Open Phantom → Settings → Developer Settings → Testnet Mode. Choose Robinhood Chain Testnet and the same account as “Pay from” below.'));
    guide.append(node('p', 'On mobile, open this site inside Phantom’s browser. You need test tokens and test ETH for gas. Linking a wallet does not switch its network.'));
    root.append(guide);
    const walletLabel = node('label', 'Pay from'), walletSelect = node('select');
    for (const candidate of accountState().wallets.filter(w => w.chainType === 'ethereum')) {
      const option = node('option', `${candidate.kind === 'embedded' ? 'Privy' : 'External wallet'} · ${candidate.address.slice(0, 8)}…${candidate.address.slice(-6)}`);
      option.value = candidate.address; option.selected = candidate.address === wallet.address; walletSelect.append(option);
    }
    walletSelect.addEventListener('change', () => { chooseFundingWallet(walletSelect.value); wallet = fundingWallet(); });
    walletLabel.append(walletSelect); root.append(walletLabel);
    disclosure.append(node('p', `Your wallet needs test tokens and test ETH for gas: ${wallet.address}`));
    const controller = createTopupController({ api: fundingRequest, storage: localStorage,
      storageKey: `vault-topup:${config.assetHash}:${owner}`, send: sendTestnetDeposit,
      onProgress: stage => {
        if (current()) status.textContent = {
          review: 'Checking the amount and recipient…',
          wallet: 'Open Phantom to review the network and transfer. Confirm once in the wallet. Keep this page open.',
          confirmations: 'Transfer submitted. Waiting for network confirmations. No second transfer is needed.'
        }[stage];
      } });
    const inputLabel = node('label', `Top-up amount (maximum ${amount(config.maximumTopup)})`);
    const input = node('input'); input.inputMode = 'decimal'; input.autocomplete = 'off'; input.placeholder = '1.00'; inputLabel.append(input); root.append(inputLabel);
    const previousTopup = controller.read();
    if (previousTopup?.input?.amountBaseUnits && previousTopup.state !== 'complete') input.value = amount(previousTopup.input.amountBaseUnits);
    const orderLabel = node('p'); root.append(orderLabel);
    const describe = result => {
      const order = result.order;
      orderLabel.textContent = `Order ${order.id} · ${amount(order.minimumReceived)} test tokens · ${order.credited ? 'Credited' : order.state}`;
      return order.credited ? 'Top-up credited. Refresh balances to see your available credit.'
        : Date.now() > order.expiresAt && !order.submittedTransactionHash && !order.transactionHash
          ? 'This order expired. If you never signed it, use Review top-up to prepare another. If you signed, recover the transaction hash first.'
          : 'Top-up remains pending. Check the same order again.';
    };
    button(root, 'Review top-up', () => run(async () => {
      const result = await controller.prepare({ wallet: wallet.address, amountBaseUnits: tokenAmount(input.value, config.asset.decimals) });
      describe(result); confirm.hidden = false; return `Review ${amount(result.order.minimumReceived)} test tokens to ${config.asset.destination}. Gas is additional. Click Confirm only once.`;
    }));
    const confirm = button(root, 'Confirm testnet transfer', () => run(async () => {
      const result = await controller.confirm(); confirm.hidden = true; return describe(result);
    })); confirm.hidden = true;
    const recovery = node('details'); recovery.append(node('summary', 'Recover a top-up'));
    const hashLabel = node('label', 'Transaction hash (only needed if the wallet sent but the page lost its response)');
    const hashInput = node('input'); hashInput.placeholder = '0x…'; hashInput.autocomplete = 'off'; hashLabel.append(hashInput); recovery.append(hashLabel);
    button(recovery, 'Recover / check top-up', () => run(async () => describe(await controller.recover(hashInput.value.trim() || undefined))));
    if (controller.read()?.state === 'signing-unknown' && !controller.read()?.hash) {
      recovery.append(node('p', 'Only use the next option if the wallet failed before you signed and you have closed any pending request. A missing transaction in the explorer alone is not enough.'));
      button(recovery, 'I did not sign a transfer: review again', () => run(async () => {
        await controller.acknowledgeNotSigned({ confirmedNoSignature: true });
        return 'No new transfer was sent. Click Review top-up to check the same amount and wallet again.';
      }));
    }
    button(root, 'Refresh balances', () => { if (!busy) openFunding(); });
    const saved = controller.read();
    if (saved && saved.state !== 'complete') { status.textContent = `Pending top-up: ${saved.state}. Recover it before starting another.`; recovery.open = true; }
    root.append(recovery, disclosure);
    const history = await fundingRequest('/api/funding/deposits'); if (!current()) return;
    const historyView = node('details'); historyView.append(node('summary', 'Recent top-ups'));
    if (history.deposits.length) root.append(historyView);
    for (const { order } of history.deposits) {
      const row = node('p', `${amount(order.minimumReceived)} · ${order.credited ? 'Credited' : order.state} · ${order.id}`);
      historyView.append(row);
      button(historyView, 'Check this order', () => run(async () => describe(await fundingRequest(`/api/funding/deposits/${order.id}/check`, {}))));
    }
  } catch (error) { if (current()) root.replaceChildren(node('p', error.message)); }
}
document.addEventListener('vault:account-changed', () => {
  if (activeOwner === accountState()?.accountId) return;
  generation++;
  if (document.querySelector('#info-title')?.textContent === 'Top up & bounty') document.querySelector('#info-dialog').close();
});
accessConfiguration.then(config => {
  if (!config.webFundingEnabled) return;
  button(document.querySelector('#account-credits').parentElement, 'Top up & bounty', openFunding);
  document.querySelector('#account-mode-note').textContent = 'Testnet funding rehearsal. No monetary value or cash payouts.';
  document.querySelector('.treasury-intro').textContent = 'Practice for free or test the wallet-to-credit flow. Only testnet tokens are accepted.';
});
