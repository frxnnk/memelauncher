// Network identity shared by the wallet and the server. Testnet only.
export const FUNDING_NETWORK = Object.freeze({
  id: 46630, chainId: '46630', hexId: '0xb626', name: 'Robinhood Chain Testnet',
  rpcUrl: 'https://rpc.testnet.chain.robinhood.com',
  explorerUrl: 'https://explorer.testnet.chain.robinhood.com',
  faucetUrl: 'https://faucet.testnet.chain.robinhood.com',
  nativeCurrency: Object.freeze({ name: 'Ether', symbol: 'ETH', decimals: 18 })
});
export const walletChain = () => ({ id: FUNDING_NETWORK.id, name: FUNDING_NETWORK.name, testnet: true,
  nativeCurrency: { ...FUNDING_NETWORK.nativeCurrency }, rpcUrls: { default: { http: [FUNDING_NETWORK.rpcUrl] } },
  blockExplorers: { default: { name: 'Robinhood Testnet Explorer', url: FUNDING_NETWORK.explorerUrl } } });

export function checkedDepositTransaction(prepared, now = Date.now()) {
  const order = prepared?.order, tx = prepared?.transfer?.transaction;
  const address = value => typeof value === 'string' && /^0x[0-9a-f]{40}$/i.test(value);
  if (prepared?.environment !== 'testnet' || prepared.realFundsEnabled !== false ||
      !prepared.transfer?.signingEnabled || !tx || tx.chainId !== FUNDING_NETWORK.hexId ||
      order?.asset?.chainId !== FUNDING_NETWORK.chainId || !Number.isSafeInteger(order.expiresAt) || now > order.expiresAt ||
      order.credited || order.submittedTransactionHash || order.transactionHash || tx.value !== '0x0' ||
      !address(tx.from) || !address(tx.to) || !address(order.owner) || !address(order.asset.tokenAddress) || !address(order.asset.destination) ||
      tx.from.toLowerCase() !== order.owner.toLowerCase() || tx.to.toLowerCase() !== order.asset.tokenAddress.toLowerCase() ||
      typeof order.minimumReceived !== 'string' || !/^[1-9][0-9]{0,77}$/.test(order.minimumReceived) || BigInt(order.minimumReceived) >= 2n ** 256n) {
    throw new Error('A current Robinhood testnet deposit order is required.');
  }
  const expected = '0xa9059cbb' + order.asset.destination.slice(2).toLowerCase().padStart(64, '0') + BigInt(order.minimumReceived).toString(16).padStart(64, '0');
  if (tx.data !== expected) throw new Error('The transfer differs from the reviewed amount or destination.');
  return { from: tx.from, to: tx.to, data: tx.data, value: tx.value, chainId: tx.chainId };
}
