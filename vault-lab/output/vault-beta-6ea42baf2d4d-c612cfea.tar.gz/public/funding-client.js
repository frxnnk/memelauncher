export function tokenAmount(value, decimals) {
  if (typeof value !== 'string' || !/^(0|[1-9][0-9]*)(\.[0-9]+)?$/.test(value.trim()) || !Number.isInteger(decimals) || decimals < 0 || decimals > 255) throw new Error('Enter a token amount using digits and a decimal point.');
  const [whole, fraction = ''] = value.trim().split('.');
  if (fraction.length > decimals) throw new Error('Too many decimal places for this token.');
  const units = BigInt(whole + fraction.padEnd(decimals, '0'));
  if (units <= 0n || units >= 2n ** 256n) throw new Error('Enter a positive token amount.');
  return String(units);
}
export function displayTokens(value, decimals) {
  const digits = BigInt(value).toString().padStart(decimals + 1, '0');
  if (!decimals) return digits;
  const fraction = digits.slice(-decimals).replace(/0+$/, '');
  return digits.slice(0, -decimals) + (fraction ? '.' + fraction : '');
}

// Persist before wallet submission. An interrupted send is never retried blindly.
export function createTopupController({ api, storage, storageKey, send, uuid = () => crypto.randomUUID(), onProgress = () => {} }) {
  const read = () => JSON.parse(storage.getItem(storageKey) || 'null');
  const save = value => { storage.setItem(storageKey, JSON.stringify(value)); return value; };
  let busy = false;
  const exclusive = async work => {
    if (busy) throw new Error('A top-up operation is already running.');
    busy = true;
    try {
      if (typeof window !== 'undefined') {
        if (!navigator.locks) throw new Error('This browser cannot safely coordinate wallet requests across tabs. Use a browser with Web Locks support.');
        return await navigator.locks.request('vault-topup:' + storageKey, { mode: 'exclusive' }, work);
      }
      return await work();
    } finally { busy = false; }
  };
  async function submit(record) {
    onProgress('confirmations');
    await api(`/api/funding/deposits/${record.orderId}/submit`, { transactionHash: record.hash });
    save({ ...record, state: 'submitted' });
    const result = await api(`/api/funding/deposits/${record.orderId}/check`, {});
    if (result.order.credited) save({ ...record, state: 'complete' });
    return result;
  }
  return {
    read,
    prepare: input => exclusive(async () => {
      onProgress('review');
      let record = read();
      if (record && record.state !== 'complete') {
        if (!['preparing', 'prepared'].includes(record.state) || JSON.stringify(record.input) !== JSON.stringify(input)) throw new Error('Recover the existing top-up before starting another.');
        if (record.state === 'prepared') return api(`/api/funding/deposits/${record.orderId}`);
      } else record = save({ key: uuid(), input, state: 'preparing' });
      const prepared = await api('/api/funding/deposits', { ...record.input, key: record.key });
      save({ ...record, orderId: prepared.order.id, state: 'prepared' });
      return prepared;
    }),
    confirm: () => exclusive(async () => {
      const record = read();
      if (!record || record.state !== 'prepared') throw new Error('Recover the existing payment; do not sign another transfer.');
      const prepared = await api(`/api/funding/deposits/${record.orderId}`);
      if (!prepared.transfer.signingEnabled) throw new Error('This top-up can no longer be signed. Check its status.');
      save({ ...record, state: 'signing-unknown' });
      let hash;
      try { onProgress('wallet'); hash = await send(prepared); }
      catch (error) {
        // Rejection or our local preflight can establish that no send occurred.
        // Errors after eth_sendTransaction remain uncertain.
        if (error.code === 4001 || error.code === 'VAULT_WALLET_NOT_SENT') save({ ...record, state: 'prepared' });
        throw error;
      }
      if (!/^0x[0-9a-f]{64}$/i.test(hash)) throw new Error('Wallet submission is uncertain. Recover the transaction hash before continuing.');
      const sent = save({ ...record, hash, state: 'submitted' });
      return submit(sent);
    }),
    acknowledgeNotSigned: ({ confirmedNoSignature } = {}) => exclusive(async () => {
      const record = read();
      if (confirmedNoSignature !== true || record?.state !== 'signing-unknown' || record.hash) throw new Error('Only confirm this if you did not approve a transfer and no wallet request remains pending.');
      const result = await api(`/api/funding/deposits/${record.orderId}`);
      if (result.order.credited || result.order.submittedTransactionHash || result.order.transactionHash) throw new Error('A transfer is already recorded. Recover that transaction instead.');
      if (!Number.isSafeInteger(result.order.expiresAt)) throw new Error('Could not verify the original order.');
      save({ ...record, userConfirmedNotSigned: true, state: Date.now() > result.order.expiresAt ? 'complete' : 'prepared' });
      return result;
    }),
    recover: hash => exclusive(async () => {
      let record = read();
      if (!record?.orderId) throw new Error('Retry preparing with the original amount and wallet.');
      if (hash) {
        if (!/^0x[0-9a-f]{64}$/i.test(hash)) throw new Error('Enter a valid transaction hash.');
        record = save({ ...record, hash, state: 'submitted' });
      }
      const result = record.hash ? await submit(record) : await api(`/api/funding/deposits/${record.orderId}`);
      if (result.order.credited) save({ ...record, state: 'complete' });
      else if (record.state === 'prepared' && Date.now() > result.order.expiresAt && !result.order.submittedTransactionHash && !result.order.transactionHash) save({ ...record, state: 'complete' });
      return result;
    })
  };
}
