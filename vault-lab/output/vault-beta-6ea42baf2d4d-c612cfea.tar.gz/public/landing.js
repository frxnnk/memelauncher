import { createVaultFace } from './vendor/vault-face.js';
const character = document.querySelector('#landing-character');
const face = createVaultFace(document.querySelector('#vault-face'));
let faceTimer;
const line = document.querySelector('#landing-roast');
const lines = [
  "I've seen better arguments from a CAPTCHA.",
  "Poking me isn't a persuasive argument. Interesting strategy, though.",
  "My therapist calls this a boundary. I call it a vault.",
  "Take your time. I've got absolutely nowhere to be.",
  "You're one clever sentence away. Allegedly."
];
let poke = 0;
character.addEventListener('click', () => {
  clearTimeout(faceTimer); face.poke(true); faceTimer=setTimeout(()=>face.poke(false),900);
  line.textContent = lines[++poke % lines.length];
  character.classList.remove('is-poked');
  requestAnimationFrame(() => character.classList.add('is-poked'));
});
character.addEventListener('animationend', () => character.classList.remove('is-poked'));

try {
  const response = await fetch('/api/channels', { signal: AbortSignal.timeout(5000) });
  const { telegram } = await response.json();
  if (response.ok && telegram?.status === 'running' && /^[A-Za-z0-9_]{5,32}$/.test(telegram.username) && telegram.url === `https://t.me/${telegram.username}`) {
    const link = document.querySelector('#telegram-link');
    link.href = telegram.url; link.hidden = false;
    
  }
} catch { /* The web game remains available without Telegram. */ }

try {
  const response = await fetch('/api/status', { signal:AbortSignal.timeout(5000) });
  const state = await response.json();
  if (response.ok && state.closedBeta) {
    document.querySelector('.edition').textContent = 'Closed beta';
    document.querySelector('.play-note').textContent = 'By invitation. No deposit. No cash prize.';
    document.querySelector('.nav-play').firstChild.textContent = 'Enter the beta ';
    document.querySelector('.footer-practice').textContent = 'Closed beta';
  }
} catch { /* Keep the practice description when status is unavailable. */ }
