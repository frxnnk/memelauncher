import { readFileSync, mkdirSync } from 'node:fs';
import { join } from 'node:path';
import { createAssetEconomy } from './asset-service.mjs';
import { createAuthenticatedDeposits } from './authenticated-deposits.mjs';
import { createAuthenticatedCreditGame } from './authenticated-game.mjs';
import { createDepositReader } from './deposit-rpc.mjs';
import { createDepositMonitor } from './deposit-monitor.mjs';
import { createCreditHistory } from './credit-history.mjs';
import { createWebFunding } from './web-funding.mjs';
import { units, roundTerms, id } from './schema.mjs';
import { validateDepositAsset } from './deposit.mjs';
import { FUNDING_NETWORK } from '../../public/funding-network.js';

export function validateWebFundingConfiguration(config) {
  if (!config || config.environment !== 'testnet') throw new Error('Only testnet web funding is implemented.');
  const asset = validateDepositAsset(config.asset);
  if (asset.chainId !== FUNDING_NETWORK.chainId) throw new Error('The web rehearsal uses Robinhood Chain Testnet. Mainnet funding is disabled.');
  if (!units(config.maximumTopup) || !Array.isArray(config.rounds) || !config.rounds.length || config.rounds.length > 3) throw new Error('Explicit top-up limit and rounds are required.');
  const terms = roundTerms(config.terms);
  if (units(terms.price) > units(config.maximumTopup)) throw new Error('The attempt price exceeds the top-up limit.');
  const roundIds = new Set();
  for (const round of config.rounds) {
    id(round.id);
    if (roundIds.has(round.id) || !Array.isArray(round.models) || round.models.length !== 1) throw new Error('Each funding round must have one guardian and a unique ID.');
    roundIds.add(round.id);
  }
  return { ...config, asset, terms };
}

export async function startWebFunding({ configPath, dataDirectory, authentication, limits, vault, beta, rpcUrl }) {
  const config = validateWebFundingConfiguration(JSON.parse(readFileSync(configPath, 'utf8')));
  const reader = createDepositReader({ rpcUrl, expectedChainId: config.asset.chainId });
  await reader.head(); // Fail startup before accepting top-ups on the wrong network.
  mkdirSync(dataDirectory, { recursive: true });
  let economy, monitor, game;
  try {
    economy = createAssetEconomy({ path: join(dataDirectory, 'credits.sqlite'), asset: config.asset, terms: config.terms });
    for (const round of config.rounds) economy.openRound(round.id, round.models);
    monitor = createDepositMonitor({ economy, reader, policy: { batchSize: 20, intervalMs: 15000, maxAgeMs: 120000 } });
    await monitor.runBatch(); monitor.start();
    game = createAuthenticatedCreditGame({ path: join(dataDirectory, 'jobs.sqlite'), economy, authentication, limits, vault, depositMonitor: monitor });
    const deposits = createAuthenticatedDeposits({ economy, authentication, reader });
    return { funding: createWebFunding({ economy, deposits, game, authentication, beta, maximumTopup: config.maximumTopup, testnet: true }),
      creditHistory: createCreditHistory({ game, deposits }),
      async close() { await monitor.close(); game.close(); economy.close(); } };
  } catch (error) { await monitor?.close(); game?.close(); economy?.close(); throw error; }
}
