import { build } from 'esbuild';
await build({ entryPoints: ['client/privy.mjs'], outfile: 'public/vendor/privy.js', bundle: true,
  platform: 'browser', format: 'esm', target: ['es2022'], minify: true, sourcemap: false,
  legalComments: 'linked', logLevel: 'info' });
