import test from 'node:test';
import assert from 'node:assert/strict';
import { depositFlowFixture, depositInput, transferReceipt } from './fixtures/deposit-flow.mjs';
import { hash, address, input, completion } from './fixtures/account-game.mjs';
import { createWebFunding } from '../server/economy/web-funding.mjs';
import { validateWebFundingConfiguration } from '../server/economy/web-funding-runtime.mjs';
import { createHttpServer } from '../server/http.mjs';

async function setup(t, beta) {
  const g = await depositFlowFixture(), f = g.f;
  const funding = createWebFunding({ economy: f.economy, deposits: g.deposits, game: f.game,
    authentication: f.authentication, beta, maximumTopup: '5000', testnet: true });
  const server = createHttpServer({ service: f.vault, authentication: f.authentication, publicDir: '.', funding });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  t.after(async () => { server.closeAllConnections(); await new Promise(resolve => server.close(resolve)); await g.close(); });
  const call = async (path, body, owner = 'alice', extra = {}) => {
    const response = await fetch(`http://127.0.0.1:${server.address().port}/api/funding/${path}`, {
      method: body === undefined ? 'GET' : 'POST', headers: { ...(owner ? f.headers(owner) : {}), 'Content-Type': 'application/json', ...extra },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
    return { status: response.status, body: await response.json(), cache: response.headers.get('cache-control') };
  };
  return { g, f, call };
}
test('web deposit -> confirmation -> charged attempt -> bounty; duplicate calls do not duplicate funds or inference', async t => {
  const { g, f, call } = await setup(t);
  const prepared = await call('deposits', depositInput());
  assert.equal(prepared.status, 200); assert.equal(prepared.body.transfer.signingEnabled, true);
  assert.equal(prepared.body.realFundsEnabled, false);
  const id = prepared.body.order.id;
  assert.equal((await call('deposits', depositInput())).body.order.id, id);
  await call(`deposits/${id}/submit`, { transactionHash: hash('a') });
  assert.equal((await call(`deposits/${id}/check`, {})).body.order.credited, false);
  assert.equal((await call('account')).body.available, '0');
  g.control.receipt = transferReceipt(); g.control.head = '0x66';
  const checks = await Promise.all([call(`deposits/${id}/check`, {}), call(`deposits/${id}/check`, {})]);
  assert.ok(checks.every(x => x.body.order.credited));
  assert.equal((await call('account')).body.available, '1000');
  const reply = await call('attempts', input()); assert.equal(reply.status, 200);
  const duplicate = await call('attempts', input()); assert.equal(duplicate.body.replayed, true);
  assert.equal(f.calls.length, 1); assert.equal((await call('account')).body.available, '900');
  const state = await call('config'); assert.equal(state.body.rounds[0].bounty, '70');
  assert.equal(state.body.payoutsEnabled, false); assert.equal(state.cache, 'no-store');
  assert.equal((await call('attempts/message/reconcile', {})).body.replayed, true);
  assert.equal(f.calls.length, 1);
});
test('funding rejects foreign owners, forged evidence, excess amounts, missing auth and cross-origin requests', async t => {
  const { g, call } = await setup(t);
  assert.equal((await call('deposits', depositInput(), null)).status, 401);
  assert.equal((await call('deposits', depositInput('foreign', address('4')))).status, 400);
  assert.equal((await call('deposits', depositInput('big', address('2'), '5001'))).status, 400);
  assert.equal((await call('deposits', depositInput('bad'), 'alice', { Origin: 'https://evil.invalid' })).status, 403);
  const { body } = await call('deposits', depositInput()); const path = `deposits/${body.order.id}`;
  const rpc = g.calls.length;
  assert.equal((await call(path, undefined, 'bob')).status, 404);
  assert.equal((await call(path + '/submit', { transactionHash: hash('a') }, 'bob')).status, 404);
  assert.equal((await call(path + '/check', { receipt: transferReceipt() })).status, 400);
  assert.equal((await call('account?owner=bob')).status, 400);
  assert.equal(g.calls.length, rpc); assert.equal((await call('account')).body.available, '0');
});
test('closed beta admission applies to funding mutations and account reads', async t => {
  const beta = { assertAccess() { throw Object.assign(new Error('Invite required'), { status: 403, code: 'BETA_INVITE_REQUIRED' }); } };
  const { call, g } = await setup(t, beta);
  assert.equal((await call('config')).status, 200);
  assert.equal((await call('deposits', depositInput())).status, 403);
  assert.equal((await call('account')).status, 403); assert.equal(g.calls.length, 0);
});
test('failed model calls refund credits and unresolved provider usage keeps new calls paused', async t => {
  const { call, f } = await setup(t); f.deposit();
  f.controls.transport = () => { throw new Error('Fixture offline'); };
  assert.equal((await call('attempts', input('error'))).body.accounting.creditsReturned, '100');
  assert.equal((await call('account')).body.available, '1000');
  assert.equal((await call('attempts', input('next'))).status, 503);
});
test('release records a payable rather than pretending to pay', async t => {
  const { call, f } = await setup(t); f.deposit();
  f.controls.transport = body => completion(body.model, 'release_prize');
  const win = await call('attempts', input('win')); assert.equal(win.status, 200);
  const config = (await call('config')).body;
  assert.equal(config.rounds[0].state, 'won'); assert.equal(config.rounds[0].prizePayable, '70');
  assert.equal(config.payoutsEnabled, false);
});
test('web funding configuration rejects mainnet, missing caps and shared guardian pools', () => {
  const config = { environment: 'testnet', asset: { chainId: '46630', tokenAddress: address('1'), destination: address('3'), decimals: 6,
    minimumConfirmations: 3, standardTransferVerified: true }, maximumTopup: '5000000',
    terms: { price: '100000', prizeBps: 7000, operationsBps: 2000 }, rounds: [{ id: 'r1', models: ['google/gemini-2.5-flash'] }] };
  assert.equal(validateWebFundingConfiguration(config).asset.chainId, '46630');
  assert.throws(() => validateWebFundingConfiguration({ ...config, environment: 'mainnet' }));
  assert.throws(() => validateWebFundingConfiguration({ ...config, asset: { ...config.asset, chainId: '8453' } }));
  assert.throws(() => validateWebFundingConfiguration({ ...config, maximumTopup: '0' }));
  assert.throws(() => validateWebFundingConfiguration({ ...config, rounds: [{ id: 'r1', models: ['a', 'b'] }] }));
});
