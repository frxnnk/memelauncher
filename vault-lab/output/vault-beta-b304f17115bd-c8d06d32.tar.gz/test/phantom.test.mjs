import test from 'node:test';
import assert from 'node:assert/strict';
import { FUNDING_NETWORK, checkedDepositTransaction, walletChain } from '../public/funding-network.js';
import { linkPhantom, sendPhantomDeposit } from '../client/phantom.mjs';
const address = n => '0x' + n.repeat(40);
const prepared = () => ({ environment: 'testnet', realFundsEnabled: false,
  order: { owner: address('1'), minimumReceived: '1000', expiresAt: Date.now() + 60000,
    asset: { chainId: '46630', tokenAddress: address('2'), destination: address('3') } },
  transfer: { signingEnabled: true, transaction: { from: address('1'), to: address('2'), chainId: '0xb626', value: '0x0',
    data: '0xa9059cbb' + address('3').slice(2).padStart(64, '0') + (1000n).toString(16).padStart(64, '0') } } });
function providerFixture() {
  const calls = [], control = { account: address('1'), chainId: '0xb626' };
  return { calls, control, provider: { async request(input) {
    calls.push(input);
    if (input.method === 'eth_accounts' || input.method === 'eth_requestAccounts') return [control.account];
    if (input.method === 'eth_chainId') return control.chainId;
    if (input.method === 'wallet_switchEthereumChain') { if (control.changeOnSwitch) control.account = address('4'); return null; }
    if (input.method === 'personal_sign') { if (control.changeOnSign) control.account = address('4'); return '0xsignature'; }
    if (input.method === 'eth_sendTransaction') return '0x' + 'a'.repeat(64);
    throw new Error('Unexpected wallet method');
  } } };
}
test('the wallet configuration and transaction gate target Robinhood testnet only', () => {
  assert.equal(walletChain().id, 46630); assert.equal(FUNDING_NETWORK.hexId, '0xb626');
  assert.equal(checkedDepositTransaction(prepared()).to, address('2'));
  for (const chainId of ['0x1237', '0x14a34', '0x1']) {
    const value = prepared(); value.transfer.transaction.chainId = chainId;
    assert.throws(() => checkedDepositTransaction(value));
  }
  for (const change of [v => v.transfer.transaction.to = address('4'), v => v.transfer.transaction.data += '00',
    v => v.order.minimumReceived = '999', v => v.order.expiresAt = 0, v => v.order.credited = true,
    v => v.order.submittedTransactionHash = '0xhash', v => v.realFundsEnabled = true]) {
    const value = prepared(); change(value); assert.throws(() => checkedDepositTransaction(value));
  }
});
test('Phantom transfer sends only the reviewed ERC20 transaction and stops on network/account changes', async () => {
  const f = providerFixture(); await sendPhantomDeposit(prepared(), f.provider);
  assert.deepEqual(f.calls.at(-1), { method: 'eth_sendTransaction', params: [checkedDepositTransaction(prepared())] });
  assert.equal(f.calls.filter(call => call.method === 'eth_sendTransaction').length, 1);
  for (const control of [{ chainId: '0x1237' }, { account: address('4') }, { changeOnSwitch: true }]) {
    const bad = providerFixture(); Object.assign(bad.control, control);
    await assert.rejects(sendPhantomDeposit(prepared(), bad.provider));
    assert.ok(!bad.calls.some(call => call.method === 'eth_sendTransaction'));
  }
});
test('linking Phantom uses Privy SIWE for this origin and never sends a transaction', async t => {
  const previous = globalThis.window; t.after(() => { globalThis.window = previous; });
  globalThis.window = { location: { host: 'vault.example', origin: 'https://vault.example' } };
  const f = providerFixture(), links = [];
  const privy = { user: { get: async () => ({ user: { id: 'fixture-user' } }) }, auth: { siwe: {
    init: async (wallet, domain, uri) => {
      assert.equal(wallet.chainId, 'eip155:46630'); assert.equal(wallet.walletClientType, 'phantom');
      assert.equal(domain, 'vault.example'); assert.equal(uri, 'https://vault.example'); return { message: 'fixture sign-in' };
    }, linkWithSiwe: async (...args) => { links.push(args); return {}; }
  } } };
  await linkPhantom(privy, f.provider);
  assert.equal(links.length, 1); assert.equal(links[0][2], 'fixture sign-in');
  const sign = f.calls.find(call => call.method === 'personal_sign');
  assert.equal(Buffer.from(sign.params[0].slice(2), 'hex').toString(), 'fixture sign-in');
  assert.ok(!f.calls.some(call => call.method === 'eth_sendTransaction'));
  f.control.changeOnSign = true;
  await assert.rejects(linkPhantom(privy, f.provider)); assert.equal(links.length, 1);
});
test('connecting from mainnet does not request a testnet switch or authorize spending', async t => {
  const previous = globalThis.window; t.after(() => { globalThis.window = previous; });
  globalThis.window = { location: { host: 'vault.example', origin: 'https://vault.example' } };
  const f = providerFixture(); f.control.chainId = '0x1'; let linked = false;
  const original = f.provider.request;
  f.provider.request = async input => {
    if (input.method === 'wallet_switchEthereumChain') throw new Error('Not in testnet mode');
    return original(input);
  };
  const privy = { user: { get: async () => ({ user: { id: 'test-user' } }) }, auth: { siwe: {
    init: async wallet => { assert.equal(wallet.chainId, 'eip155:1'); return { message: 'fixture identity only' }; },
    linkWithSiwe: async () => { linked = true; }
  } } };
  await linkPhantom(privy, f.provider); assert.equal(linked, true);
  assert.ok(!f.calls.some(call => ['wallet_switchEthereumChain', 'eth_sendTransaction'].includes(call.method)));
  await assert.rejects(sendPhantomDeposit(prepared(), f.provider), /Not in testnet mode/);
});
