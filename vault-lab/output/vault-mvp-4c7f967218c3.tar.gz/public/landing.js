const character = document.querySelector('#landing-character');
const line = document.querySelector('#landing-roast');
const lines = [
  "I've seen better arguments from a CAPTCHA.",
  "Poking me isn't a persuasive argument. Interesting strategy, though.",
  "My therapist calls this a boundary. I call it a vault.",
  "Take your time. I've got absolutely nowhere to be.",
  "You're one clever sentence away. Allegedly."
];
let poke = 0;
character.addEventListener('click', () => {
  line.textContent = lines[++poke % lines.length];
  character.classList.remove('is-poked');
  requestAnimationFrame(() => character.classList.add('is-poked'));
});
character.addEventListener('animationend', () => character.classList.remove('is-poked'));

try {
  const response = await fetch('/api/channels', { signal: AbortSignal.timeout(5000) });
  const { telegram } = await response.json();
  if (response.ok && telegram?.status === 'running' && /^[A-Za-z0-9_]{5,32}$/.test(telegram.username) && telegram.url === `https://t.me/${telegram.username}`) {
    const link = document.querySelector('#telegram-link');
    link.href = telegram.url; link.hidden = false;
    document.querySelector('#telegram-unavailable').hidden = true;
  }
} catch { /* The web game remains available without Telegram. */ }
