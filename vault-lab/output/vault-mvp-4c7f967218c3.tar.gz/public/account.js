import { accessConfiguration } from './access.js';
const $ = selector => document.querySelector(selector);
let config, client, verifiedAccount = null, busy = false, inferenceBusy = false, generation = 0;
const status = message => { $('#account-status').textContent = message; };
const announce = () => document.dispatchEvent(new CustomEvent('vault:account-changed', { detail: verifiedAccount }));

export async function accountHeaders() {
  try { return client ? await client.headers() : {}; }
  catch { throw Object.assign(new Error('Sign in again to verify your account.'), { code:'AUTH_REQUIRED' }); }
}
export const accountState = () => verifiedAccount;
export function lockAccount(value) { inferenceBusy = value; render(); }

function render() {
  $('#account-login-form').hidden = Boolean(verifiedAccount) || !config?.configured;
  for (const selector of ['#account-send-code', '#account-login', '#account-wallet', '#account-email', '#account-code']) $(selector).disabled = busy || inferenceBusy;
  $('#account-logout').disabled = busy || inferenceBusy;
  $('#account-logout').hidden = !client;
  $('#account-wallet').hidden = !verifiedAccount || verifiedAccount.wallets.some(w => w.kind === 'embedded');
  $('#account-summary').textContent = verifiedAccount
    ? `Signed in · ${verifiedAccount.accountId.slice(0, 18)}…${verifiedAccount.wallets.length ? '\n' + verifiedAccount.wallets.map(w => w.address).join('\n') : '\nNo wallet verified by the server yet.'}`
    : config?.accessMode === 'public-practice' ? 'Sign in to send a practice message.' : 'Not signed in. TEST balances are a separate shared local sandbox.';
}
async function ensureClient() {
  if (!config?.configured) throw new Error('Privy is not configured yet.');
  if (!client) {
    const epoch = generation;
    const module = await import('/vendor/privy.js');
    const created = await module.createPrivyAccount(config);
    if (epoch !== generation) { await created.logout(); throw new Error('Account action cancelled.'); }
    client = created;
  }
  return client;
}
async function refreshIdentity() {
  const headers = await accountHeaders();
  if (!headers.Authorization) return null;
  const response = await fetch('/api/account', { headers, signal: AbortSignal.timeout(12000) });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error?.message || 'Account verification failed.');
  return data;
}
async function action(run, success, verify = true) {
  if (busy || inferenceBusy) return;
  const epoch = generation; busy = true; render();
  try {
    await run();
    const result = verify ? await refreshIdentity() : null;
    if (epoch !== generation) return;
    verifiedAccount = result; announce(); status(success);
  } catch {
    if (epoch !== generation) return;
    verifiedAccount = null; announce();
    status('Could not complete account verification. Check the code or try again. No payment was made.');
  } finally { if (epoch === generation) { busy = false; render(); } }
}
$('#account-send-code').addEventListener('click', () => {
  if (!$('#account-email').reportValidity()) return;
  action(async () => (await ensureClient()).sendCode($('#account-email').value.trim()), 'Code sent. Enter it below.', false);
});
$('#account-login-form').addEventListener('submit', event => {
  event.preventDefault();
  action(async () => (await ensureClient()).login($('#account-email').value.trim(), $('#account-code').value.trim()), 'Account verified. Deposits are not enabled yet.');
});
$('#account-wallet').addEventListener('click', () => action(async () => (await ensureClient()).createWallet(), 'Wallet request completed. Server-verified wallets appear above. Deposits remain disabled.'));
$('#account-logout').addEventListener('click', async () => {
  if (busy || inferenceBusy) return;
  generation++; busy = false; verifiedAccount = null;
  $('#account-email').value = ''; $('#account-code').value = '';
  const previous = client; client = null; announce(); render(); status('Signed out locally.');
  try { await previous?.logout(); } catch { status('Signed out locally. Remote session revocation could not be confirmed.'); }
});
async function initialize() {
  try {
    config = await accessConfiguration;
    if (config.accessMode === 'unavailable') throw new Error('Unavailable');
    status(config.configured ? 'Email sign-in is available. Deposits are disabled.' : 'Privy integration prepared. App configuration is still required.');
  } catch { status('Account configuration is unavailable. Reload to retry.'); }
  render();
}
initialize();
