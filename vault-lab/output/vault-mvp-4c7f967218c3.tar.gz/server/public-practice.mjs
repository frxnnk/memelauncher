import { meteredAttempt } from './metered-attempt.mjs';

export function createPublicPractice({ vault, authentication, limits }) {
  return {
    async attempt(headers, input) {
      const principal = await authentication.authenticate(headers);
      return meteredAttempt({ vault, limits, input, scope: { ownerId: principal.accountId } });
    },
    async usage(headers) { return limits.status((await authentication.authenticate(headers)).accountId); }
  };
}
