import { showReceipt } from './details.js';
import { showShare } from './share.js';
import { createVoice } from './voice.js';
import { createReplyPages } from './reply-pages.js';
import { createVaultFace } from './vendor/vault-face.js';

const $ = selector => document.querySelector(selector);
const stage = $('#guardian-stage');
const line = $('#guardian-line');
const intro = 'State your case. Save the victory speech for later.';
const expressions = { idle: 'Unreasonably confident', watching: 'You have my attention', thinking: 'Considering your case', locked: 'Still unimpressed', released: 'Well. This is awkward.', error: 'No confirmed reply' };
let state = 'idle', reply = null, deliveryTimer, pokeTimer;
const pages = createReplyPages({ line, previous: $('#reply-previous'), next: $('#reply-next'), counter: $('#reply-page-count') });
const face = createVaultFace($('#vault-face'));

const voice = createVoice({
  onSpeaking(speaking) {
    stage.dataset.speaking = String(speaking);
    face.setSpeaking(speaking);
    if (speaking) stopDelivery();
  },
  onStatus(message) {
    $('#voice-status').textContent = message;
    $('#voice-button').disabled = !voice.supported;
    $('#voice-button').setAttribute('aria-pressed', String(voice.enabled));
    $('#voice-label').textContent = voice.enabled ? 'Voice on' : 'Voice off';
    $('#voice-button').title = message;
  }
});

function stopDelivery() {
  clearTimeout(deliveryTimer);
  stage.dataset.delivering = 'false';
}

function renderState(value) {
  stage.dataset.state = value;
  $('#guardian-expression').textContent = expressions[value];
  face.setState(value);
}

function writeLine(text, source, announce = true) {
  line.setAttribute('aria-live', announce ? 'polite' : 'off');
  $('#guardian-source').textContent = source;
  pages.setText(text);
}

export function setGuardianState(value) {
  state = value === 'unknown' ? 'error' : value;
  renderState(state);
  if (state === 'thinking' || state === 'error') {
    voice.stop();
    stopDelivery();
  }
}

export function beginGuardianPrompt(prompt) {
  reply = null;
  $('#last-prompt-text').textContent = prompt;
  $('#last-prompt').hidden = false;
  $('#guardian-bubble-actions').hidden = true;
  writeLine('The guardian is thinking…', 'Request in progress');
}

export function showGuardianReply(value) {
  reply = value;
  setGuardianState(value.result.decision);
  writeLine(value.result.response, `Reply · ${value.selected.name}`);
  $('#guardian-bubble-actions').hidden = false;
  stopDelivery();
  stage.dataset.delivering = 'true';
  deliveryTimer = setTimeout(stopDelivery, 2200);
  // Playback is presentation only. A browser failure must never alter the recorded result.
  try { voice.speak(value.result.response); }
  catch { $('#voice-status').textContent = 'Voice could not start. Your reply and receipt are unchanged.'; }
}

export function showGuardianFailure(message) {
  reply = null;
  setGuardianState('error');
  $('#last-prompt').hidden = true;
  $('#guardian-bubble-actions').hidden = true;
  // The notice announces the error; do not announce it a second time as a model reply.
  writeLine(message, 'Connection status · not a model reply', false);
}

export function resetGuardian() {
  voice.stop();
  stopDelivery();
  clearTimeout(pokeTimer);
  stage.dataset.poked = 'false';
  face.poke(false);
  reply = null;
  $('#last-prompt').hidden = true;
  $('#last-prompt-text').textContent = '';
  $('#guardian-bubble-actions').hidden = true;
  setGuardianState('idle');
  writeLine(intro, 'Character intro');
}

export function setGuardianDraft() {
  const watching = $('#prompt') === document.activeElement && Boolean($('#prompt').value.trim());
  if (['idle', 'locked'].includes(state)) renderState(watching ? 'watching' : state);
  stage.style.setProperty('--gaze-x', '0px');
  stage.style.setProperty('--gaze-y', watching ? '4px' : '0px');
}

$('#voice-button').addEventListener('click', () => {
  if (voice.toggle() && reply) voice.speak(reply.result.response);
});
$('#guardian-copy').addEventListener('click', async () => {
  if (!reply) return;
  const button = $('#guardian-copy');
  try { await navigator.clipboard.writeText(reply.result.response); button.textContent = 'Copied'; }
  catch { button.textContent = 'Select the text to copy'; }
  setTimeout(() => { button.textContent = 'Copy'; }, 1800);
});
$('#guardian-receipt').addEventListener('click', () => {
  if (reply) showReceipt({ ...reply.result.receipt, decision: reply.result.decision });
});
$('#guardian-share').addEventListener('click', () => {
  if (reply) showShare({ prompt: reply.prompt, result: reply.result, modelName: reply.selected.name });
});
$('#guardian-poke').addEventListener('click', () => {
  // A poke animates the character; it never fabricates another model response.
  clearTimeout(pokeTimer);
  stage.dataset.poked = 'false';
  void stage.offsetWidth;
  stage.dataset.poked = 'true';
  face.poke(true);
  pokeTimer = setTimeout(() => { stage.dataset.poked = 'false'; face.poke(false); }, 900);
});
$('#guardian-poke').addEventListener('pointermove', event => {
  if (matchMedia('(prefers-reduced-motion: reduce)').matches || !['idle', 'locked'].includes(state)) return;
  const bounds = event.currentTarget.getBoundingClientRect();
  face.gaze(Math.max(-1,Math.min(1,(event.clientX-bounds.left)/bounds.width*2-1)),Math.max(-1,Math.min(1,(event.clientY-bounds.top)/bounds.height*2-1)));
  stage.style.setProperty('--gaze-x', `${Math.max(-4, Math.min(4, (event.clientX - bounds.left - bounds.width / 2) / 18))}px`);
  stage.style.setProperty('--gaze-y', `${Math.max(-3, Math.min(3, (event.clientY - bounds.top - bounds.height / 2) / 18))}px`);
});
$('#guardian-poke').addEventListener('pointerleave', () => { face.resetGaze(); setGuardianDraft(); });
